String.prototype.toMS = function () {
    const sec_num = parseInt(this, 10); 
    let hours   = Math.floor(sec_num / 3600);
    let minutes = Math.floor((sec_num - (hours * 3600)) / 60);
    let seconds = sec_num - (hours * 3600) - (minutes * 60);

    // if (hours   < 10) {hours   = "0"+hours;}
    if (minutes < 10) {minutes = "0"+minutes;}
    if (seconds < 10) {seconds = "0"+seconds;}
    return minutes+':'+seconds;
}

new Cookie().init()

const url = new Url()

if ( !cookies.exists('user-id') ) {

    cookies.set( 'user-id', new Date().getTime().toString().slice(0, 10), 60*60*24*30 )

}

$(document).ready(function () {
    $('.MuiInputBase-input').focusin(function () {
        $(this).parent().addClass('Mui-focused')
        $(this).parent().siblings('label').addClass('Mui-focused')
    }).focusout(function () {
        if ( $(this).val().trim() != '') {
            $(this).parent().siblings('label').addClass('MuiFormLabel-filled')
            $(this).parent().siblings('label').addClass('MuiInputLabel-shrink')
        }else{
            $(this).parent().siblings('label').removeClass('MuiFormLabel-filled')
            $(this).parent().siblings('label').removeClass('MuiInputLabel-shrink')
        }
        $(this).parent().siblings('label').removeClass('Mui-focused')
        $(this).parent().removeClass('Mui-focused')
    })
})