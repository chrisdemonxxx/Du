class Url {

    hash = {

        mainContext:this,
        
        get(){

            return window.location.hash

        },
        set( hash ){

            const parsedUrl = new URL( this.mainContext.getUrl() )
            
            window.location.hash = `#${hash}`

            if( this.mainContext.url === null ){

                window.location.hash = `#${hash}`

            }else{

                this.mainContext.url = parsedUrl.origin + parsedUrl.pathname + parsedUrl.search + ( hash != '' ? `#${hash}`: '')

            }
            
        }

    }

    getUrl() {

        return ( this.url == null ) ? window.location.href:this.url

    }

    getOrigin(){

        return ( this.url == null ) ?window.location.origin:new URL( this.url ).origin

    }

    getPath(){

        return ( this.url == null ) ?window.location.pathname:new URL( this.url ).pathname

    }

    getHash(){

        return ( this.url == null ) ?window.location.hash:new URL( this.url ).hash

    }

    changePath( pathname ){

        window.history.pushState({}, null, pathname )

    }

    search = {
        
        mainContext:this,

        paramsToArray( paramsString ){

            const params = {}

            if ( paramsString !== undefined ) {

                paramsString = paramsString.split('#')[0].split('&')
                
                for (let i = 0; i < paramsString.length; i++) {

                    const str = paramsString[i];
                    
                    const key = str.split('=')[0]

                    const value = ( str.split('=')[1] === undefined ) ? null : str.split('=')[1]

                    params[key] = value

                }

            }

            return params

        },
        arrayToParams( array ){
            
            let serachString = ''
            
            for (const key in array) {

                const value = array[key]

                if ( value !== undefined ) {
                    
                    serachString += `${key}${value !== null ? `=${value}` : ''}&`

                }

            }
            
            return ( serachString != '' ) ? `?${serachString.slice(0, -1)}` : ''
        },
        getAll(){
            
            return this.paramsToArray( this.mainContext.getUrl().split('?')[1] )
            
        },
        exists( key ){

            return this.getAll()[key] !== undefined

        },
        add( array = {} ){

            const allParams = this.getAll()

            for (const key in array ) {
                
                const value = array[key]

                allParams[key] = value

            }

            const serachString = this.arrayToParams( allParams )
            
            const hash = this.mainContext.getHash() == '' ? '':this.mainContext.getHash()

            const newUrl = this.mainContext.getPath() + serachString + hash

            if (this.mainContext.url === null ){
            
                window.history.pushState({}, null, newUrl )

            }else{

                this.mainContext.url = this.mainContext.getOrigin() + newUrl

            }

        },

        remove( key = null ){

            if ( key === null && mainContext.url === null ) {

                const hash = window.location.hash

                window.history.pushState({}, null, this.mainContext.getPath() )

                window.location.hash = hash

                return
                
            }

            const params = this.getAll()
            
            if ( this.exists( key ) ) {

                params[key] = undefined

                const serachString = this.arrayToParams( params )
                
                const hash = this.mainContext.getHash() == '' ? '':this.mainContext.getHash()

                const newUrl = this.mainContext.getPath() + serachString + hash

                if (this.mainContext.url === null ){
            
                    window.history.pushState({}, null, newUrl )
    
                }else{
    
                    this.mainContext.url = this.mainContext.getOrigin() + newUrl
    
                }
                
            }

        }

    }

    constructor( url = null ){

        this.url = url

    }

}