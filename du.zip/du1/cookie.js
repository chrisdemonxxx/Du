class Cookie {

    #original  = ''

    get = {}

    set( name, value, time, path = '/' ) {
        
        time = String(time).match(/\d/g) !== null ? Number(String(time).match(/\d/g).join('')) * 1000 : 1000

        const date = new Date()

        date.setTime( date.getTime() + time )
        
        let expires = `expires=${date.toUTCString()}`
        
        document.cookie = `${name.trim()}=${value};${expires};path=${path}`
        
    }
    
    delete( name ) {
    
        this.exists( name ) ? this.set( name, '', -1 ) : false
    
    }

    exists( name ){
        
        return this.#get()[name] !== undefined

    }
    
    init() {

        if ( window.cookies === undefined ) {
            
            this.#update()
            
            this.changeListener()

        }else{
            
            console.error('Cookie class already declared use: cookie variable' )
            
        }

    }

    changeListener( callback ){

        setInterval( ()=> {

            if ( this.#original  != document.cookie) {
                
                this.#update()

                if ( typeof callback == 'function' ) {
                    
                    callback()

                }

            }

        }, 100)

    }
    
    #get() {
    
        const cookiesStrs = document.cookie.split(';')
       
        let result = {};
        
        if ( cookiesStrs[0] == '' ) {

            return result

        }

        for (let i = 0; i < cookiesStrs.length; i++) {
    
            const cookieStr = cookiesStrs[i];
    
            const name = cookieStr.split('=')[0].trim()
    
            const value = cookieStr.split('=')[1]
            
            result[name] = value
    
        }
    
        return result
    
    }

    #update() {
        
        const cookies = this.#get()

        this.get = {}

        for (const name in cookies ) {
            
            const value = cookies[name]

            this.get[name] = value

        }

        this.#original  = document.cookie

        window.cookies = this

    }

}