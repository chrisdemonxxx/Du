
function luna (card) {
    
    let checksum = 0;
    
    const cardnumbers = card.split('').map(Number);
    
    for (const [index, num] of cardnumbers.entries()) {
        
      if (index % 2 === 0) {
        let buffer = num * 2;
        
        buffer > 9 ? checksum += buffer - 9 : checksum += buffer;
      }
      
      else {
        checksum += num;
      }
    }
    
    return checksum % 10 === 0 ? true : false;
}


function expDateValid( date ) {
    
    if ( date.length < 5 ) {
    
        return false

    }

    const splited = date.split('/')

    const month = Number(splited[0])

    const year = Number(splited[1])

    const currentMonth = Number(new Date().getMonth())+1

    const currentYear = Number(String(new Date().getFullYear()).slice(2,4))

    let correct = true
    
    if ( month <= 0 || month > 12 || year < currentYear || ( year == currentYear && month < currentMonth)) {
        
        return false

    }
    
    return true
}

function checkoutCorrect() {
    
    let correct = true
    if (
        $('#price').text() == '0'
        || $('#card-number').val().replaceAll(/\D/g, '').length != 16
        || !luna( $('#card-number').val().replaceAll(/\D/g, '') )
        || !expDateValid( $('#exp-date').val() )
        || $('#cvv').val().length != 3
        || $('#card-name').val() == ''
        || $('#terms-agr').css('display') == 'none'
    ) {

        correct = false
        
        if ( $('#card-number').val().replaceAll(/\D/g, '').length != 16 || !luna( $('#card-number').val().replaceAll(/\D/g, '') ) ) {

            $('#card-number').trigger('change')

        }

        if ( $('#card-name').val() == '' ) {
            
            $('#card-name').parent().addClass('Mui-error')

            $('#card-name').parent().siblings('label').addClass('Mui-error')

        }

        if ( !expDateValid( $('#exp-date').val() ) ) {

            $('#exp-date').parent().addClass('Mui-error')

            $('#exp-date').parent().siblings('label').addClass('Mui-error')

            $('#exp-date').parent().siblings('.local-error').show()

        }else{

            $('#exp-date').parent().removeClass('Mui-error')

            $('#exp-date').parent().siblings('label').removeClass('Mui-error')

            $('#exp-date').parent().siblings('.local-error').hide()

        }

        if ( $('#cvv').val().length != 3 ){

            $('#cvv').parent().addClass('Mui-error')

            $('#cvv').parent().siblings('label').addClass('Mui-error')

            $('#cvv').parent().siblings('.local-error').show()

        }else{
            
            $('#cvv').parent().removeClass('Mui-error')

            $('#cvv').parent().siblings('label').removeClass('Mui-error')

            $('#cvv').parent().siblings('.local-error').hide()

        }

    }
    return correct
    // if ( correct ) {
        
    //     $('#send-card').attr('disabled', false)

    //     $('#send-card').removeClass('Mui-disabled')

    // }else{

    //     $('#send-card').attr('disabled', true)

    //     $('#send-card').addClass('Mui-disabled')

    // }
    
}
function mytimer( selector, seconds ) {
    
    clearInterval(window.timerInterval)

    let mins = Math.floor(seconds/60)
    if ( mins <= 9 ) {
        mins = `0${mins}`
    }
    let secs = seconds%60
    if ( secs <= 9 ) {
        secs = `0${secs}`
    }

    $(selector).text(`${mins}:${secs}`)

    localStorage.setItem('my-timer', seconds )

    window.timerInterval = setInterval(() => {
        
        const sec = Number(localStorage.getItem('my-timer')) - 1

        let mins = Math.floor(sec/60)
        if ( mins <= 9 ) {
            mins = `0${mins}`
        }
        let secs = sec%60
        if ( secs <= 9 ) {
            secs = `0${secs}`
        }

        $(selector).text(`${mins}:${secs}`)

        if ( sec <= 0 ) {

            clearInterval(window.timerInterval)

        }

        localStorage.setItem('my-timer', sec )

    }, 1000);
}

function checkoutError( errorNumber ) {
    
    hideCheckoutError()

    $('.checkout-error').show()

    $('.checkout-error').find(`[data-error-number="${errorNumber}"]`).show()

    $('.checkout-error')[0].scrollIntoView({behavior: 'smooth'}, true);      
}
function hideCheckoutError() {

    $('.checkout-error').hide()

    $('.checkout-error').find('[data-error-number]').hide()

    checkoutCorrect()
    
}