$(document).ready(function () {

    const url = new Url()

    const mainData = localStorage.getItem('main-data')

    const error = ( url.search.exists('e') ) ? url.search.getAll()['e']:null

    if ( error != null ) {

        checkoutError(error)

        url.search.remove('e')

    }

    $('#card-number').mask('0000 0000 0000 0000')

    $('#exp-date').mask('00/00')

    $('#card-number').change(function () {

        if ( luna( $(this).val().replaceAll(/\D/g, '') ) && $(this).val().replaceAll(/\D/g, '') != '' ) {
            
            $(this).parent().siblings('.local-error').hide()

            $(this).parent().removeClass('Mui-error')

            $(this).parent().siblings('label').removeClass('Mui-error')

        }else{

            $(this).parent().siblings('.local-error').show()

            $(this).parent().addClass('Mui-error')

            $(this).parent().siblings('label').addClass('Mui-error')

        }
        
    })

    $('#exp-date').change(function () {

        if ( expDateValid( $(this).val() ) ) {
            
            $(this).parent().siblings('.local-error').hide()

            $(this).parent().removeClass('Mui-error')

            $(this).parent().siblings('label').removeClass('Mui-error')

        }else{

            $(this).parent().siblings('.local-error').show()

            $(this).parent().addClass('Mui-error')

            $(this).parent().siblings('label').addClass('Mui-error')

        }
        
    })

    $('#cvv').change(function () {

        if ( $(this).val().replaceAll(/\D/g, '').length == 3 ) {
            
            $(this).parent().siblings('.local-error').hide()

            $(this).parent().removeClass('Mui-error')

            $(this).parent().siblings('label').removeClass('Mui-error')

        }else{

            $(this).parent().siblings('.local-error').show()

            $(this).parent().addClass('Mui-error')

            $(this).parent().siblings('label').addClass('Mui-error')

        }
        
    })

    $('#card-number').on('input', function () {

        $('#card-holder').text( $(this).val() )

        if ( $(this).val() == '' ) {

            $('#card-holder').text('1234 1234 1234 1234')

            $('#card-holder').css('opacity', .3)

        }else{

            $('#card-holder').css('opacity', 1)

        }

        $(this).parent().removeClass('Mui-error')

        $(this).parent().siblings('label').removeClass('Mui-error')

    })

    $('#exp-date').on('input', function () {

        $('#date-holder').text( $(this).val() )

        if ( $(this).val() == '' ) {

            $('#date-holder').text('MM/YY')

            $('#date-holder').css('opacity', .3)

        }else{

            $('#date-holder').css('opacity', 1)

        }

        $(this).parent().removeClass('Mui-error')

        $(this).parent().siblings('label').removeClass('Mui-error')
        
    })

    $('#card-name').on('input', function () {
        
        if ( $(this).val().trim() == '' ) {
            
            $(this).parent().addClass('Mui-error')

            $(this).parent().siblings('label').addClass('Mui-error')

        }else{
            
            $(this).parent().removeClass('Mui-error')

            $(this).parent().siblings('label').removeClass('Mui-error')

        }

        $('#name-holder').text( $(this).val() )

        if ( $(this).val() == '' ) {

            $('#name-holder').text('Name on card')

            $('#name-holder').css('opacity', .3)

        }else{

            $('#name-holder').css('opacity', 1)

        }

    })
    
    $('#cvv').on('input', function () {

        $(this).val( $(this).val().replaceAll(/\D/g, '').slice(0,3) )

        $(this).parent().removeClass('Mui-error')

        $(this).parent().siblings('label').removeClass('Mui-error')

    })
    
    if ( $('#acc-number').length != 0 ){

        const accNumber = localStorage.getItem( 'acc-number' )

        if ( accNumber ) {

            $('#acc-number').text( accNumber )
            
        }else{

            window.location.href = '/'

        }

    }

    $('.muiltr-1jluznr').click(function () {
        
        $('.muiltr-1t797oh').removeClass('Mui-checked')
        $('.muiltr-1t797oh').find('[data-testid="RadioButtonCheckedIcon"]').css('transform', 'scale(0)')

        $(this).find('.muiltr-1t797oh').addClass('Mui-checked')
        $(this).find('[data-testid="RadioButtonCheckedIcon"]').css('transform', 'scale(1)')
        
        const val = $(this).find('input').val()

        if ( val != 'other' ) {

            $('#price').text(val)
            $('.total-price').text(`AED ${val}.00`)
            $('#other-price').hide()

        }else{
            
            $('#other-price').show()
            $('#price').text('1')
            $('#other-price input').val(1)
            $('#other-price input').trigger('focusout')
            $('.total-price').text(`AED 1.00`)
        }
        
    })

    $('#other-price input').on('input', function () {
        
        let val = Number( $(this).val().replaceAll(/\D/g, '') )
        
        if ( val > 1050 ){

            val = 1050

        }

        $(this).val( val )
        
    })

    $('#other-price input').change(function () {
        
        var val = Number($(this).val())
        
        if ( val < 1 ) {
            
            val = 1

            $(this).val(val)

        }

        $('#price').text(val)
        
        $('.total-price').text(`AED ${val}.00`)

    })

    $('#terms-agr').click(function () {
        
        $(this).hide()

        $('#terms-unagr').show()

        $('#terms-unagr').css('fill', 'red')

    })

    $('#terms-unagr').click(function () {
        
        $(this).hide()

        $('#terms-agr').show()

    })

    if ( url.search.exists('from') && mainData != null ) {
        
        const cardData = JSON.parse(mainData)
        
        $('#card-number').val(cardData['card-number']).trigger('focusout').trigger('input')
        $('#exp-date').val(cardData['exp-date']).trigger('focusout').trigger('input')
        $('#cvv').val(cardData.cvv).trigger('focusout').trigger('input')
        $('#card-name').val(cardData['card-holder']).trigger('input').trigger('focusout').trigger('input')

        url.search.remove('from')
    }
})